"""Shared core components."""
